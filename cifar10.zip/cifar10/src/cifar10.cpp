//============================================================================
// Name        : cifar10.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <stdio.h>
#include "tensorflow/lite/micro/examples/cifar10/main_functions.h"
#include "tensorflow/lite/micro/examples/cifar10/Input_image.h"
#define NUM_IMG 10
extern  char* itoa(int, unsigned char* , int);
/* Uncomment to send inference for each input */
#define PRT_INF
using namespace std;

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	uint8_t p_msg[] = "Image belongs to class : ";
	uint8_t p_msg1[] = "Model initialization failed...!\r\n";
	uint8_t p_msg2[] = "Model Interpretation failed...!\r\n";
	uint8_t index_prt[] = "\r\nInference Values : \r\n";
	uint8_t error_msg[] = "\r\nTotal number of Mismatch  : ";
	/* Label of respective classes  */
	unsigned char output[][50] = {"Airplane", "Automobile", "Bird", "Cat", "Deer", "Dog", "Frog", "Horse", "Ship", "Truck"};
	uint8_t new_line[] = ", \r\n";
	int* index_value;
	unsigned char inference[20];
	/* Variable to store timer and error count  */
	unsigned char timer_val[20];
	unsigned char timer_ms[20];
	unsigned char error_val[20];
	int error_cnt =0;
	uint8_t status = 0;

	/* Initializes the Cifar10 AI Model, return 1 if successfully Initialized */
	status = Setup();

	if (status == 1)
	{
	   for (int img_num=0; img_num<NUM_IMG; img_num++)
	   {
            /* Reading input image array from a file */
            const uint8_t *img_data = input_image_bmp3[img_num];
            /* Invoke cifar10 model to interpret result */
            index_value = RunInference(img_data);
            if(index_value[10] != -1)
            {
#if defined PRT_INF
                printf("%s", index_prt);
                for (uint8_t index = 0; index<10; index++)
                {
                   itoa(index_value[index],inference,10);
                   printf("%s",inference);
                   printf("%s",new_line);
                }
#endif
                printf("%s",p_msg);
                printf("%s",output[(int)index_value[10]]);
                printf("%s",new_line);

                if (index_value[10] != input_img_label[img_num])
                {
                  error_cnt +=1;
                }
            }
            else
            {
                 /* Send error message over UART */
                 printf("%s",p_msg2);
            }
	   }
	   /* Prints the error count when compared to python output */
	   printf("%s",error_msg);
	   itoa(error_cnt,error_val,10);
	   printf("%s",error_val);
	}
	 else
	 {
	    printf("%s",p_msg1);
	 }
	return 0;
}
