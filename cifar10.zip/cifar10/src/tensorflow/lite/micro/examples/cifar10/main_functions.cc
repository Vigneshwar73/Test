/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include <tensorflow/lite/micro/examples/cifar10/main_functions.h>
#include <tensorflow/lite/micro/examples/cifar10/model_settings.h>
#include <tensorflow/lite/micro/examples/cifar10/Cifar10_model.h>
#include <tensorflow/lite/micro/examples/cifar10/Input_image.h>
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/micro/all_ops_resolver.h"

int score[11];
// Globals
namespace
{
    tflite::ErrorReporter* error_reporter = nullptr;
    const tflite::Model* model = nullptr;
    TfLiteTensor* model_input = nullptr;
    tflite::MicroInterpreter* interpreter = nullptr;

    // Create an area of memory to use for input, output, and intermediate arrays.
      // Finding the minimum value for your model may require some trial and error.
      const int tensor_arena_size = CIFAR10_ARENA_SIZE;
      uint8_t tensor_arena[tensor_arena_size];
}  // namespace

// The function to initialize the model
uint8_t Setup()
{
      static tflite::MicroErrorReporter micro_error_reporter;  // NOLINT
      error_reporter = &micro_error_reporter;

      // Map the model into a usable data structure. This doesn't involve any
      // copying or parsing, it's a very lightweight operation.
      model = tflite::GetModel(g_cifar_10_model_data);

      if (model->version() != TFLITE_SCHEMA_VERSION)
      {
          error_reporter->Report("Model provided is schema version %d not equal to supported version %d.",
                             model->version(), TFLITE_SCHEMA_VERSION);
          return 0;
      }

      // Pull in only the operation implementations we need.
      // This relies on a complete list of all the ops needed by this graph.
      // An easier approach is to just use the AllOpsResolver, but this will
      // incur some penalty in code space for op implementations that are not
      // needed by this graph.
      //static tflite::AllOpsResolver resolver;

      static tflite::MicroMutableOpResolver<6> micro_op_resolver; // NOLINT
      micro_op_resolver.AddConv2D();
      micro_op_resolver.AddFullyConnected();
      micro_op_resolver.AddSoftmax();
      micro_op_resolver.AddMaxPool2D();
      micro_op_resolver.AddRelu();
      micro_op_resolver.AddReshape();

      // Build an interpreter to run the model with.
      static tflite::MicroInterpreter static_interpreter(
              model, micro_op_resolver, tensor_arena, tensor_arena_size, error_reporter);
      interpreter = &static_interpreter;

       // Allocate memory from the tensor_arena for the model's tensors
      TfLiteStatus allocate_status =  interpreter->AllocateTensors();
      if (allocate_status != kTfLiteOk)
      {
          error_reporter->Report("Allocation failed");
          return 0;
      }

      // Obtain pointer to the model's input tensor.
      model_input = interpreter->input(0);
      if ((model_input->dims->size != kNumDimension) && (model_input->dims->data[0] != 1) &&
          (model_input->dims->data[1] != kNumRows) &&
          (model_input->dims->data[2] != kNumCols) &&
          (model_input->dims->data[3] != kNumChannels) &&
          (model_input->type != kTfLiteInt8))
      {
          error_reporter->Report("Bad input tensor parameters in model");
        return 0;
      }
      return 1;
}

// The function to get predictions
int* RunInference(const uint8_t *const_pnSample)
{
    // To store the maximum score of output
    float max_Score = 0;
    float sum =0;

    // Attempt to read new data Sample array
    for (size_t i = 0; i < (model_input->bytes/(sizeof(int8_t))); ++i)
    {
        model_input->data.int8[i] = (int8_t) const_pnSample[i]/ model_input->params.scale + model_input->params.zero_point;
    }

    //Run inference, and report any error.
    TfLiteStatus invoke_status = interpreter->Invoke();
    if (invoke_status != kTfLiteOk)
    {
        error_reporter->Report("Invoke failed");
        return 0;
    }

    // Obtain a pointer to the output tensor and make sure it has the
    // properties we expect.
    TfLiteTensor* output = interpreter->output(0);
    if((output->dims->size != 2)&&
    (output->dims->data[0] != 1)&&
    (output->dims->data[1] != kCategoryCount)&&
    (output->type != kTfLiteInt8))
    {
        error_reporter->Report("Bad Output tensor parameters in model");
        score[10] = -1;
        return score;
    }

    // Get predicted class
    float nmaxScore = output->data.int8[0];
    int detectedClass = 0;
    sum =0;
    //Print the Scores value for all the class categories
    for(int class_ctg_itr = 0; class_ctg_itr < (kCategoryCount); class_ctg_itr++)
    {
        score[class_ctg_itr] = output->data.int8[class_ctg_itr];
        sum += output->data.int8[class_ctg_itr];
        if(output->data.int8[class_ctg_itr] > nmaxScore)
        {
            nmaxScore = output->data.int8[class_ctg_itr];
            detectedClass = class_ctg_itr;
        }
    }
    score[10] = detectedClass;
    return score;
}
